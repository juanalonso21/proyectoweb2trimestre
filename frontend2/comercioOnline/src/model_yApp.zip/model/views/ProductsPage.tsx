import React, { useEffect, useState } from "react";
import ProductLista from "../components/ListaProductos";
import Header from "../components/Header";
import Footer from "../components/Footer";
import { IProduct } from "../interfaces/iProduct";
import { ICategoria } from "../interfaces/iCategoria";
// import "../assets/css/ProductosPage.css";

const ProductsPage: React.FC = () => {
  const [products, setProducts] = useState<IProduct[]>([]);
  const [categories, setCategories] = useState<ICategoria[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("asc");

  useEffect(() => {
    fetchProducts();
    fetchCategories();
  }, []);

  const fetchProducts = async (): Promise<void> => {
    try {
      const response = await fetch("http://192.168.7.38:8090/api/producto/");
      const data: IProduct[] = await response.json();
      console.log("Respuesta de la API (productos):", data);
      setProducts(data);
    } catch (error) {
      console.error("Error al cargar los productos", error);
      setProducts([]);
    }
  };

  const fetchCategories = async (): Promise<void> => {
    try {
      const response = await fetch("http://192.168.7.38/api/categoria/");
      const data: ICategoria[] = await response.json();
      console.log("Respuesta de la API (categorías):", data);
      setCategories(data);
    } catch (error) {
      console.error("Error al cargar las categorías", error);
      setCategories([]);
    }
  };

  const handleCategoryChange = (e: React.ChangeEvent<HTMLSelectElement>): void => {
    setSelectedCategory(e.target.value);
  };

  const handleSortOrderChange = (e: React.ChangeEvent<HTMLSelectElement>): void => {
    setSortOrder(e.target.value as "asc" | "desc");
  };

  const filteredProducts = products
    .filter((product) => selectedCategory === "" || product.categoria?.nombre === selectedCategory)
    .sort((a, b) => (sortOrder === "asc" ? a.precio - b.precio : b.precio - a.precio));

  return (
    <>
      <Header />
      <div className="products-page container mx-auto px-4">
        <h1 className="text-center text-2xl font-bold mb-6">Productos</h1>
        <div className="flex flex-wrap justify-between mb-6">
          <div className="w-full md:w-1/3 mb-4 md:mb-0">
            <select
              className="w-full p-2 border border-gray-300 rounded"
              onChange={handleCategoryChange}
              value={selectedCategory}
            >
              <option value="">Todas las categorías</option>
              {categories.map((category) => (
                <option key={category.id} value={category.nombre}>
                  {category.nombre}
                </option>
              ))}
            </select>
          </div>
          <div className="w-full md:w-1/3">
            <select
              className="w-full p-2 border border-gray-300 rounded"
              onChange={handleSortOrderChange}
              value={sortOrder}
            >
              <option value="asc">Ordenar por precio: Menor a Mayor</option>
              <option value="desc">Ordenar por precio: Mayor a Menor</option>
            </select>
          </div>
        </div>
        <ProductLista products={filteredProducts} />
      </div>
      <Footer />
    </>
  );
};

export default ProductsPage;