import React, { useEffect, useState } from "react";
import { getProducts, createProduct, updateProduct, deleteProduct } from "../api/apiProducts";
import ProductsList from "../components/ProductsListAdmin";
import ProductForm from "../components/ProductForm";
import Sidebar from "../components/sidebaradmin";
import { IProduct } from "../interfaces/iProduct";
import { ICategoria } from "../interfaces/iCategoria";


const ProductsPageAdmin: React.FC = () => {
  const [products, setProducts] = useState<IProduct[]>([]);
  const [editingProduct, setEditingProduct] = useState<IProduct | null>(null);
  const [newProduct, setNewProduct] = useState<IProduct>({
    id: 0,
    nombre: "",
    descripcion: "",
    precio: 0,
    imagenUrl: "",
    categoria: null,
    carrito: null,
    fechaCreacion: null,
    estado: "",
  });
  const [showForm, setShowForm] = useState<boolean>(false);

  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = async () => {
    try {
      const data = await getProducts();
      setProducts(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error("Error al cargar los productos", error);
    }
  };

  const handleCreateOrUpdateProduct = async (formData: FormData) => {
    try {
      const product: IProduct = {
        id: editingProduct ? editingProduct.id : 0,
        nombre: formData.get("nombre") as string,
        descripcion: formData.get("descripcion") as string,
        precio: parseFloat(formData.get("precio") as string),
        imagenUrl: formData.get("imagenUrl") as string,
        categoria: JSON.parse(formData.get("categoria") as string) as ICategoria | null,
        carrito: null,
        fechaCreacion: null,
        estado: formData.get("estado") as string,
      };
  
      if (editingProduct) {
        await updateProduct(product.id, product);
      } else {
        await createProduct(product);
      }
  
      setNewProduct({
        id: 0,
        nombre: "",
        descripcion: "",
        precio: 0,
        imagenUrl: "",
        categoria: null,
        carrito: null,
        fechaCreacion: null,
        estado: "",
      });
      setEditingProduct(null);
      setShowForm(false);
      loadProducts();
    } catch (error) {
      console.error("Error al crear o actualizar el producto", error);
    }
  };

  const handleEditProduct = (product: IProduct) => {
    setEditingProduct(product);
    setNewProduct(product);
    setShowForm(true);
  };

  const handleDeleteProduct = async (id: number) => {
    try {
      await deleteProduct(id);
      loadProducts();
    } catch (error) {
      console.error("Error al eliminar el producto", error);
    }
  };

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement> | { target: { name: string; value: string | File | ICategoria | null } }
  ) => {
    const { name, value } = e.target;
    setNewProduct({ ...newProduct, [name]: value });
  };

  const handleAddProduct = () => {
    setEditingProduct(null);
    setNewProduct({
      id: 0,
      nombre: "",
      descripcion: "",
      precio: 0,
      imagenUrl: "",
      categoria: null,
      carrito: null,
      fechaCreacion: null,
      estado: "",
    });
    setShowForm(true);
  };

  return (
    <div className="container mx-auto px-4">
      <Sidebar />
      <h2 className="text-2xl font-bold mb-4">Productos</h2>
      <button
        className="bg-green-500 text-white py-2 px-4 rounded hover:bg-green-600 mb-4"
        onClick={handleAddProduct}
      >
        Añadir Producto
      </button>
      {showForm && (
        <div className="mb-6">
          <ProductForm
            product={newProduct}
            onChange={handleInputChange}
            onSubmit={handleCreateOrUpdateProduct}
            editingProduct={!!editingProduct}
          />
        </div>
      )}
      <ProductsList
        products={products}
        onEdit={handleEditProduct}
        onDelete={handleDeleteProduct}
      />
    </div>
  );
};

export default ProductsPageAdmin;