import React, { useState } from "react";
import CartItem from "../components/CartItem";
import Header from "../components/Header";
import Footer from "../components/Footer";
import { IProduct } from "../interfaces/iProduct";

interface ICartProduct extends IProduct {
  cantidad: number;
}

const CartPage: React.FC = () => {
  const [cart, setCart] = useState<ICartProduct[]>([
    {
      id: 1,
      nombre: "Producto 1",
      descripcion: "Descripción breve del producto 1.",
      precio: 19.99,
      carrito: null,
      categoria: null,
      fechaCreacion: null,
      imagenUrl: "/public/img/macaco-1.jpg",
      estado: "disponible",
      cantidad: 1,
    },
    {
      id: 2,
      nombre: "Producto 2",
      descripcion: "Descripción breve del producto 2.",
      precio: 29.99,
      carrito: null,
      categoria: null,
      fechaCreacion: null,
      imagenUrl: "/public/img/macaco-2.jpg",
      estado: "disponible",
      cantidad: 1,
    },
  ]);

  const handleQuantityChange = (productId: number, newQuantity: string) => {
    setCart((prevCart) =>
      prevCart.map((product) =>
        product.id === productId
          ? { ...product, cantidad: parseInt(newQuantity.toString(), 10) }
          : product
      )
    );
  };

  const handleRemove = (productId: number) => {
    setCart((prevCart) => prevCart.filter((product) => product.id !== productId));
  };

  const total = cart.reduce((sum, product) => sum + product.precio * product.cantidad, 0);

  return (
    <>
      <Header />
      <div className="container mx-auto mt-10 px-4">
        <h1 className="text-center text-2xl font-bold mb-6">Carrito de Compras</h1>
        {cart.length > 0 ? (
          <>
            <div className="space-y-6">
              {cart.map((product) => (
                <CartItem
                  key={product.id}
                  product={product}
                  onQuantityChange={handleQuantityChange}
                  onRemove={handleRemove}
                />
              ))}
            </div>
            <div className="mt-8 flex flex-col items-end">
              <div className="bg-green-100 text-green-800 p-4 rounded-md w-full md:w-1/3 text-right">
                <h4 className="text-lg font-semibold">Total: ${total.toFixed(2)}</h4>
              </div>
              <button className="mt-4 bg-blue-600 text-white py-2 px-4 rounded-md w-full md:w-1/3 hover:bg-blue-700">
                Proceder al Pago
              </button>
            </div>
          </>
        ) : (
          <div className="bg-blue-100 text-blue-800 p-4 rounded-md text-center">
            <h4 className="text-lg font-semibold">Tu carrito está vacío.</h4>
          </div>
        )}
      </div>
      <Footer />
    </>
  );
};

export default CartPage;