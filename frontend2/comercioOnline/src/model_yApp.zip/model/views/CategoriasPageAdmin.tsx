import React, { useState, useEffect } from "react";
import { getCategorias, createCategoria, updateCategoria, deleteCategoria } from "../api/apiCategorias";
import CategoriasListAdmin from "../components/CategoriasListAdmin";
import Sidebar from "../components/sidebaradmin";

interface Categoria {
  id: number;
  nombre: string;
  descripcion: string;
  icono?: string;
}

const CategoriasPageAdmin: React.FC = () => {
  const [categorias, setCategorias] = useState<Categoria[]>([]);
  const [selectedCategoria, setSelectedCategoria] = useState<Categoria | null>(null);
  const [nombre, setNombre] = useState<string>("");
  const [descripcion, setDescripcion] = useState<string>("");
  const [icono, setIcono] = useState<File | null>(null);
  const [showForm, setShowForm] = useState<boolean>(false);

  useEffect(() => {
    fetchCategorias();
  }, []);

  const fetchCategorias = async () => {
    try {
      const data = await getCategorias();
      setCategorias(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error("Error al obtener las categorías:", error);
    }
  };

  const handleEdit = (categoria: Categoria) => {
    setSelectedCategoria(categoria);
    setNombre(categoria.nombre);
    setDescripcion(categoria.descripcion);
    setShowForm(true);
  };

  const handleDelete = async (id: number) => {
    try {
      await deleteCategoria(id);
      fetchCategorias();
    } catch (error) {
      console.error("Error al eliminar la categoría:", error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
  
    // Crear el FormData para enviar
    const formData = new FormData();
    formData.append("nombre", nombre);
    formData.append("descripcion", descripcion);
  
    // Si existe un archivo, agregarlo al FormData
    if (icono) {
      formData.append("file", icono);
    }
  
    try {
      if (selectedCategoria) {
        // Enviar el FormData con la categoría seleccionada
        await updateCategoria(selectedCategoria.id, formData);
      } else {
        // Crear una nueva categoría con el FormData
        await createCategoria(formData);
      }
      fetchCategorias();
      resetForm();
    } catch (error) {
      console.error("Error al guardar la categoría:", error);
    }
  };

  const resetForm = () => {
    setSelectedCategoria(null);
    setNombre("");
    setDescripcion("");
    setIcono(null);
    setShowForm(false);
  };

  const handleAddCategoria = () => {
    resetForm();
    setShowForm(true);
  };

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      
      <div className="flex-1 p-6">
        <h2 className="text-2xl font-bold mb-6">Administración de Categorías</h2>

        <button 
          onClick={handleAddCategoria}
          className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded mb-6 transition-colors"
        >
          Añadir Categoría
        </button>

        {showForm && (
          <div className="mb-8 bg-white p-6 rounded-lg shadow-md">
            <form onSubmit={handleSubmit}>
              <div className="mb-4">
                <label htmlFor="nombre" className="block text-sm font-medium text-gray-700 mb-1">
                  Nombre
                </label>
                <input
                  type="text"
                  id="nombre"
                  value={nombre}
                  onChange={(e) => setNombre(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <div className="mb-4">
                <label htmlFor="descripcion" className="block text-sm font-medium text-gray-700 mb-1">
                  Descripción
                </label>
                <textarea
                  id="descripcion"
                  value={descripcion}
                  onChange={(e) => setDescripcion(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <div className="mb-4">
                <label htmlFor="icono" className="block text-sm font-medium text-gray-700 mb-1">
                  Icono
                </label>
                <input
                  type="file"
                  id="icono"
                  onChange={(e) => setIcono(e.target.files ? e.target.files[0] : null)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <button 
                type="submit" 
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded transition-colors"
              >
                {selectedCategoria ? "Actualizar" : "Crear"}
              </button>
            </form>
          </div>
        )}

        <CategoriasListAdmin
          categorias={categorias}
          onEdit={handleEdit}
          onDelete={handleDelete}
        />
      </div>
    </div>
  );
};

export default CategoriasPageAdmin;