import React, { useState, FormEvent, ChangeEvent } from 'react';
import { IContact } from '../model/interfaces/iContact';


const Contact: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    asunto: '',
    description: ''
  });
  
  const [formState, setFormState] = useState({
    status: 'idle' as 'idle' | 'loading' | 'success' | 'error',
    buttonLabel: 'SEND',
    showForm: true,
    showThanks: false
  });

  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const send = async (e: FormEvent) => {
    e.preventDefault();
    
    if (!formData.description || !formData.asunto || !formData.name) {
      setFormState({
        ...formState,
        status: 'error',
        buttonLabel: 'Error, try again'
      });
      return;
    }

    setFormState(prev => ({ ...prev, status: 'loading', buttonLabel: 'Sending...' }));

    const contenido: IContact = {
      content: "Me interesa:",
      embeds: [
        {
          title: formData.asunto,
          description: formData.description,
          footer: {
            text: "De: " + formData.name
          }
        }
      ]
    };

    try {
      await fetch('https://discord.com/api/webhooks/1349896265223114773/nCVe-sGiKvg3WBs-DLDIn-rhE6Tk_q32R04S9AS5Pc__JWlEYQ84j8xesht2gRQ-Eh79', {
        method: 'POST',
        body: JSON.stringify(contenido),
        headers: {
          'Content-Type': 'application/json'
        }
      });

      setFormData({ name: '', asunto: '', description: '' });
      setFormState({
        status: 'success',
        buttonLabel: 'SENT!',
        showForm: false,
        showThanks: true
      });
    } catch (error) {
      console.error('Error sending message:', error);
      setFormState({
        ...formState,
        status: 'error',
        buttonLabel: 'Error, try again'
      });
    }
  };

  const buttonClasses = {
    idle: 'bg-blue-600 hover:bg-blue-700',
    loading: 'bg-blue-400 cursor-not-allowed',
    success: 'bg-green-600 hover:bg-green-700',
    error: 'bg-red-600 hover:bg-red-700'
  };

  return (
    <div className="container bg-blue-600 text-white p-8 rounded-lg shadow-lg max-w-2xl mx-auto">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold">CONTACTA CON NOSOTROS</h2>
      </div>

      {formState.showForm && (
        <form onSubmit={send}>
          <div className="mb-4">
            <label className="block mb-2 font-medium">Nombre</label>
            <input
              name="name"
              value={formData.name}
              onChange={handleChange}
              type="text"
              placeholder="Ej. Himilce Sanchez"
              className="w-full px-4 py-2 rounded text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>

          <div className="mb-4">
            <label className="block mb-2 font-medium">Asunto</label>
            <input
              name="asunto"
              value={formData.asunto}
              onChange={handleChange}
              type="text"
              placeholder="Ej. Reparación"
              className="w-full px-4 py-2 rounded text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>

          <div className="mb-6">
            <label className="block mb-2 font-medium">Descripción</label>
            <textarea
              name="description"
              value={formData.description}
              onChange={handleChange}
              placeholder="Escríbenos lo que necesites"
              className="w-full px-4 py-2 rounded text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
              rows={4}
              required
            />
          </div>

          <div className="text-center">
            <button
              type="submit"
              disabled={formState.status === 'loading'}
              className={`px-6 py-2 rounded-full text-white font-medium transition-colors duration-200 ${
                buttonClasses[formState.status]
              } ${formState.status === 'loading' ? 'animate-pulse' : ''}`}
            >
              {formState.buttonLabel}
            </button>
          </div>
        </form>
      )}

      {formState.showThanks && (
        <div className="text-center py-8">
          <h3 className="text-xl font-bold mb-4">GRACIAS POR CONTACTARNOS</h3>
          <p className="mb-4">Nos pondremos en contacto contigo pronto.</p>
          <button
            onClick={() => setFormState({
              status: 'idle',
              buttonLabel: 'SEND',
              showForm: true,
              showThanks: false
            })}
            className="px-6 py-2 bg-blue-500 hover:bg-blue-600 rounded-full text-white font-medium transition-colors duration-200"
          >
            Enviar otro mensaje
          </button>
        </div>
      )}
    </div>
  );
};

export default Contact;