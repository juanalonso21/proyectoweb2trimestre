import React, { useState } from "react";
import { Link, Routes, Route } from "react-router-dom";
import UsersPage from "../views/UserPage";

interface NavItemProps {
  icon: string;
  text: string;
  isOpen: boolean;
  to: string;
}

const NavItem: React.FC<NavItemProps> = ({ icon, text, isOpen, to }) => {
  return (
    <Link
      to={to}
      className="flex items-center p-3 text-gray-700 hover:bg-blue-50 hover:text-blue-600 rounded-lg transition-colors"
    >
      <i className={`bx ${icon} text-xl`}></i>
      {isOpen && <span className="ml-3">{text}</span>}
    </Link>
  );
};

const Sidebar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(true);

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <div
        className={`bg-white shadow-md flex flex-col ${
          isOpen ? "w-64" : "w-20"
        } transition-all duration-300`}
      >
        <div className="flex items-center justify-between p-4 border-b">
          {isOpen && (
            <div className="flex items-center text-xl font-semibold text-blue-600">
              <i className="bx bx-layer mr-2"></i>
              <span>Admin</span>
            </div>
          )}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="p-2 rounded-lg hover:bg-gray-100"
          >
            <i className={`bx bx-menu text-xl`}></i>
          </button>
        </div>

        <nav className="flex-1 p-2 space-y-1 overflow-y-auto">
          <NavItem
            icon="bx-user"
            text="Users"
            isOpen={isOpen}
            to="/admin/usuarios"
          />
          <NavItem
            icon="bx-message-square-detail"
            text="Categorias"
            isOpen={isOpen}
            to="/admin/categorias"
          />
          <NavItem
            icon="bx-bookmark"
            text="Productos"
            isOpen={isOpen}
            to="/admin/productos"
          />
        </nav>

        <div className="p-2 border-t">
          <NavItem icon="bx-log-out" text="Sign Out" isOpen={isOpen} to="/" />
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        <Routes>
          <Route path="/usuarios" element={<UsersPage />} />
          {/* Add more routes as needed */}
        </Routes>
      </div>
    </div>
  );
};

export default Sidebar;