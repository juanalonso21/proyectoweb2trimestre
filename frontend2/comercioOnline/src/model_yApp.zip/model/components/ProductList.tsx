import React from "react";
import { IProduct } from "../interfaces/iProduct";
import ProductCard from "../components/ProductCard";

interface ProductListProps {
    products: IProduct[];
  }
  
  const ProductList: React.FC<ProductListProps> = ({ products }) => {
    return (
        <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold text-center mb-8">Nuestros Productos</h1>
      
      {/* Grid de productos */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {products.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
      );
    };
    
    export default ProductList;