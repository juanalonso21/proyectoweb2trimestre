export interface ICarousel {
    imagenUrl: string;
    titulo: string;
    descripcion: string;
  }