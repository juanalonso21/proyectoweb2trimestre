import apiClient from "./apiClient";
import { IProduct } from "../interfaces/iProduct";

// Obtener todos los productos
export const getProducts = async (): Promise<IProduct[]> => {
  try {
    const response = await apiClient.get<IProduct[]>("/producto/");
    return response.data;
  } catch (error) {
    console.error("Error al obtener los productos:", error);
    throw error;
  }
};

// Obtener un producto por ID
export const getProductById = async (id: number): Promise<IProduct> => {
  try {
    const response = await apiClient.get<IProduct>(`/producto/${id}`);
    return response.data;
  } catch (error) {
    console.error(`Error al obtener el producto con ID ${id}:`, error);
    throw error;
  }
};

// Crear un nuevo producto
export const createProduct = async (productData: IProduct): Promise<IProduct> => {
  try {
    const response = await apiClient.post<IProduct>("/producto/create", productData);
    return response.data;
  } catch (error) {
    console.error("Error al crear el producto:", error);
    throw error;
  }
};

// Actualizar un producto
export const updateProduct = async (id: number, productData: IProduct): Promise<IProduct> => {
  try {
    const response = await apiClient.put<IProduct>(`/producto/update/${id}`, productData);
    return response.data;
  } catch (error) {
    console.error(`Error al actualizar el producto con ID ${id}:`, error);
    throw error;
  }
};

// Eliminar un producto
export const deleteProduct = async (id: number): Promise<void> => {
  try {
    await apiClient.delete(`/producto/delete/${id}`);
  } catch (error) {
    console.error(`Error al eliminar el producto con ID ${id}:`, error);
    throw error;
  }
};