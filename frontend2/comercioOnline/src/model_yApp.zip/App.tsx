import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import ProductsPage from "./model/views/ProductsPage";
import ProductsPageAdmin from "./model/views/ProductsPageAdmin";
import CategoriasPageAdmin from "./model/views/CategoriasPageAdmin";
import UsersPage from "./model/views/UserPage";
import CartPage from "./model/views/CartPage";

function App() {
  return (
    <Router>
      <div className="App">
        <Routes>
          {/* Ruta para la página de productos */}
          <Route path="/" element={<ProductsPage />} />
          {/* Ruta para la página de administración de productos */}
          <Route path="/admin/products" element={<ProductsPageAdmin />} />
          {/* Ruta para la página de administración de categorías */}
          <Route path="/admin/categories" element={<CategoriasPageAdmin />} />
          {/* Ruta para la página de administración de usuarios */}
          <Route path="/admin/users" element={<UsersPage />} />
          {/* Ruta para la página del carrito */}
          <Route path="/cart" element={<CartPage />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;